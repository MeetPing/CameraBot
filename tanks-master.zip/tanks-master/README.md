Tanks
======

Multiplayer tank game developed in nodejs.

Play it [here](https://rubentd-tanks.herokuapp.com/)

Demo
=====
![online tanks game](screenshots/tanks_1.gif)